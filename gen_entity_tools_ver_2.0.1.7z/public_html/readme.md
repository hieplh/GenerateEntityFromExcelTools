**Update ver 2.0:**
- missing type java. Default String type
- convert type java based on specified type at template
- add import library based on specified library at template
- converting coding japanese to utf-8
- create zip file if download